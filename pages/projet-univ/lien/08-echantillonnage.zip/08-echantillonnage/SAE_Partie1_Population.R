# ==============================================================================
# SAE - Échantillonnage et Estimation
# Partie 1 : Estimation du nombre d'habitants d'une région de France
# DE MATHA Manon & RENARD Louis - BUT SD - S2
# ==============================================================================

# Définition du répertoire de travail
setwd("E:/A1-cours/A1-SAE/SAE statistique inférentielle")

# Chargement de la librairie sampling (fonctions de sondage stratifié)
# install.packages("sampling")  # À décommenter si pas encore installé
library(sampling)

# ==============================================================================
# 1. IMPORTATION ET PRÉPARATION DES DONNÉES
# ==============================================================================

# Lecture du fichier CSV contenant les populations communales (Insee, 2020)
donnees <- read.csv2("données.csv")

# On ne garde que les communes de Bretagne et les 3 colonnes utiles
donnees <- donnees[donnees$Nom.de.la.région == "Bretagne",
                   c("Code.département", "Commune", "Population.totale")]

# Aperçu des 6 premières lignes
head(donnees)

# ==============================================================================
# 2. DÉFINITION DE LA POPULATION ET DU TOTAL RÉEL
# ==============================================================================

# U : vecteur des noms de communes (= la population statistique)
U <- donnees$Commune

# N : nombre total de communes en Bretagne
N_total <- length(U)
N_total

# T : nombre exact d'habitants en Bretagne (valeur à estimer)
T_reel <- sum(donnees$Population.totale)
T_reel

# ==============================================================================
# PARTIE 1.1 : ÉCHANTILLONNAGE ALÉATOIRE SIMPLE
# ==============================================================================

# On va répéter 10 fois le tirage d'un échantillon de n = 100 communes
# selon un sondage aléatoire simple (s.a.s.) sans remise.
# Pour chaque tirage, on estime T et on calcule un IDC à 95%.

n <- 100  # Taille de l'échantillon

# Data frame pour stocker les résultats des 10 tirages
resultIDC <- data.frame(Pop.Total = c(), Test = c(),
                        idc_T1 = c(), idc_T2 = c(),
                        marge.erreur = c())

for (i in 1:10) {

  # Tirage aléatoire simple de n = 100 communes parmi U
  E <- sample(U, n)

  # Création de donnees1 : sous-table correspondant à l'échantillon tiré
  donnees1 <- donnees[donnees$Commune %in% E, ]

  # Nombre moyen d'habitants par commune dans l'échantillon
  xbar <- mean(donnees1$Population.totale)

  # IDC à 95% pour la moyenne µ (test de Student)
  idcmoy <- t.test(donnees1$Population.totale)$conf.int

  # Estimation du total T : T_est = N_total * xbar
  # (on multiplie la moyenne de l'échantillon par le nombre total de communes)
  T_est <- N_total * xbar

  # IDC pour T : on multiplie les bornes de l'IDC de µ par N_total
  idcT <- idcmoy * N_total

  # Marge d'erreur : demi-largeur de l'IDC
  marge <- (idcT[2] - idcT[1]) / 2

  # Ajout des résultats dans le tableau
  resTemp <- data.frame(Pop.Total = T_reel, Test = T_est,
                        idc_T1 = idcT[1], idc_T2 = idcT[2],
                        marge.erreur = marge)
  resultIDC <- rbind(resultIDC, resTemp)
}

# Affichage des résultats du s.a.s.
print(resultIDC)

# ==============================================================================
# PARTIE 1.2 : ÉCHANTILLONNAGE ALÉATOIRE STRATIFIÉ
# ==============================================================================

# On reprend les données de Bretagne et on définit 4 strates basées
# sur les quartiles de la variable Population.totale.

# Affichage des quartiles pour déterminer les bornes des strates
summary(donnees$Population.totale)

# Création de la variable strate par découpage en 4 classes
# Strate 1 : Population < 716.5 (communes les moins peuplées)
# Strate 2 : 716.5 <= Population < 1390.0
# Strate 3 : 1390.0 <= Population < 2761.5
# Strate 4 : Population >= 2761.5 (communes les plus peuplées)
donnees$strate <- cut(donnees$Population.totale,
                      breaks = c(0, 716.5, 1390.0, 2761.5, Inf),
                      labels = c(1, 2, 3, 4))

# Création de la table stratifiée, triée par strate
datastrat <- donnees[order(donnees$strate), ]
head(datastrat)

# Effectif de chaque strate (Nh)
Nh <- table(datastrat$strate)
Nh

# Nombre total de communes (vérification)
N_total <- sum(Nh)
N_total

# Poids des strates : gh = Nh / N_total
gh <- Nh / N_total
gh

# On va répéter 10 fois le tirage stratifié avec n = 100 communes,
# réparties proportionnellement dans les strates.

n <- 100  # Taille totale de l'échantillon

# Data frame pour stocker les résultats des 10 tirages
resultIDC2 <- data.frame(Pop.Total = c(), Test = c(),
                         idc_T1 = c(), idc_T2 = c(),
                         marge.erreur = c())

for (i in 1:10) {

  # Calcul des effectifs par strate (allocation proportionnelle)
  nh <- as.integer(round(c(n * Nh[1] / N_total, n * Nh[2] / N_total,
                           n * Nh[3] / N_total, n * Nh[4] / N_total)))

  # Taux de sondage dans chaque strate : fh = nh / Nh
  fh <- nh / Nh

  # Tirage stratifié (sans remise dans les strates)
  st <- strata(datastrat, stratanames = c("strate"),
               size = nh, method = "srswor")
  data1 <- getdata(datastrat, st)

  # Définition des 4 sous-échantillons
  ech1 <- data1[data1$strate == 1, ]
  ech2 <- data1[data1$strate == 2, ]
  ech3 <- data1[data1$strate == 3, ]
  ech4 <- data1[data1$strate == 4, ]

  # Moyennes estimées des 4 strates
  m1 <- mean(ech1$Population.totale)
  m2 <- mean(ech2$Population.totale)
  m3 <- mean(ech3$Population.totale)
  m4 <- mean(ech4$Population.totale)

  # Variances estimées des 4 strates
  var1 <- var(ech1$Population.totale)
  var2 <- var(ech2$Population.totale)
  var3 <- var(ech3$Population.totale)
  var4 <- var(ech4$Population.totale)

  # Moyenne stratifiée : Xbar_strat = somme(Nh * mh) / N_total
  Xbarst <- (Nh[1] * m1 + Nh[2] * m2 + Nh[3] * m3 + Nh[4] * m4) / N_total

  # Estimation de la variance de Xbar_strat
  # Var(Xbar_strat) = somme( gh² * (1 - fh) * Var_h / nh )
  varXbarst <- (gh[1])^2 * (1 - fh[1]) * var1 / nh[1] +
               (gh[2])^2 * (1 - fh[2]) * var2 / nh[2] +
               (gh[3])^2 * (1 - fh[3]) * var3 / nh[3] +
               (gh[4])^2 * (1 - fh[4]) * var4 / nh[4]

  # IDC à 95% pour µ (loi normale, grands échantillons)
  alpha <- 0.05
  binf <- Xbarst - qnorm(1 - alpha / 2) * sqrt(varXbarst)
  bsup <- Xbarst + qnorm(1 - alpha / 2) * sqrt(varXbarst)
  idcmoy <- c(binf, bsup)

  # Estimation du total T : Tstr = N_total * Xbar_strat
  Tstr <- N_total * Xbarst

  # IDC pour T : on multiplie les bornes de l'IDC de µ par N_total
  idcT <- idcmoy * N_total

  # Marge d'erreur : demi-largeur de l'IDC
  marge <- (idcT[2] - idcT[1]) / 2

  # Ajout des résultats dans le tableau
  resTemp <- data.frame(Pop.Total = T_reel, Test = Tstr,
                        idc_T1 = idcT[1], idc_T2 = idcT[2],
                        marge.erreur = marge)
  resultIDC2 <- rbind(resultIDC2, resTemp)
}

# Affichage des résultats du sondage stratifié (4 strates)
print(resultIDC2)

# ==============================================================================
# PARTIE 1.3 : AMÉLIORATION — STRATIFICATION PAR DÉCILES (10 STRATES)
# ==============================================================================

# Avec 4 strates par quartiles, la strate 4 contient des communes de 2 762 à
# 226 654 habitants : sa variance interne est très élevée. En augmentant le
# nombre de strates à 10 (déciles), on obtient des groupes plus homogènes,
# ce qui devrait réduire la variance et donc la marge d'erreur.

# Calcul des déciles
deciles <- quantile(donnees$Population.totale, probs = seq(0, 1, 0.1))
deciles

# Création de la variable strate à 10 niveaux
donnees$strate10 <- cut(donnees$Population.totale,
                        breaks = deciles,
                        labels = 1:10,
                        include.lowest = TRUE)

# Table stratifiée triée par strate
datastrat10 <- donnees[order(donnees$strate10), ]

# Effectifs des 10 strates
Nh10 <- table(datastrat10$strate10)
Nh10
N_total <- sum(Nh10)

# Poids des strates
gh10 <- Nh10 / N_total

# Boucle de 10 tirages stratifiés (10 strates, n = 100)
n <- 100

resultIDC3 <- data.frame(Pop.Total = c(), Test = c(),
                         idc_T1 = c(), idc_T2 = c(),
                         marge.erreur = c())

for (i in 1:10) {

  # Effectifs par strate (allocation proportionnelle)
  nh10 <- as.integer(round(n * Nh10 / N_total))

  # Correction si la somme des nh10 ne fait pas exactement n (arrondis)
  diff <- n - sum(nh10)
  if (diff != 0) {
    idx <- which.max(Nh10)
    nh10[idx] <- nh10[idx] + diff
  }

  # Taux de sondage par strate
  fh10 <- nh10 / Nh10

  # Tirage stratifié sans remise
  st10 <- strata(datastrat10, stratanames = c("strate10"),
                 size = nh10, method = "srswor")
  data10 <- getdata(datastrat10, st10)

  # Vecteur des niveaux de strate
  strates <- levels(datastrat10$strate10)

  # Calcul des moyennes et variances par strate (boucle sur les strates)
  moyennes <- c()
  variances <- c()
  for (s in strates) {
    ech_s <- data10[data10$strate10 == s, ]
    moyennes[s] <- mean(ech_s$Population.totale)
    variances[s] <- var(ech_s$Population.totale)
  }

  # Moyenne stratifiée (calcul global)
  Xbarst10 <- sum(Nh10 * moyennes) / N_total

  # Variance de la moyenne stratifiée (calcul global)
  varXbarst10 <- sum((gh10)^2 * (1 - fh10) * variances / nh10)

  # IDC à 95% pour µ
  alpha <- 0.05
  binf <- Xbarst10 - qnorm(1 - alpha / 2) * sqrt(varXbarst10)
  bsup <- Xbarst10 + qnorm(1 - alpha / 2) * sqrt(varXbarst10)

  # Estimation du total et IDC
  Tstr10 <- N_total * Xbarst10
  idcT <- c(binf, bsup) * N_total
  marge <- (idcT[2] - idcT[1]) / 2

  resTemp <- data.frame(Pop.Total = T_reel, Test = Tstr10,
                        idc_T1 = idcT[1], idc_T2 = idcT[2],
                        marge.erreur = marge)
  resultIDC3 <- rbind(resultIDC3, resTemp)
}

# Affichage des résultats (10 strates par déciles)
print(resultIDC3)

# ==============================================================================
# EXPORTATION DES RÉSULTATS
# ==============================================================================

# Export en CSV pour exploitation dans Excel (tableaux et graphiques)
write.csv2(resultIDC, "res_IDC1.csv")
write.csv2(resultIDC2, "res_IDC2.csv")
write.csv2(resultIDC3, "res_IDC3.csv")
