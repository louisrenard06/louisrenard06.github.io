# ==============================================================================
# SAE - Echantillonnage et Estimation
# Partie 2 : Traitement de données d'enquête
# DE MATHA Manon & RENARD Louis - BUT SD - S2
# ==============================================================================

# Définition du répertoire de travail
setwd("E:/IUT NIORT/L1/S2/SAE/Echantillonage et estimation")

# ==============================================================================
# 1. IMPORTATION DES DONNÉES
# ==============================================================================

# Lecture du fichier CSV (séparateur ; et décimale ,)
# Le fichier a été converti manuellement depuis le format Excel au préalable
sport <- read.csv2("EnqueteSportEtudiant2024.csv", sep=";", dec=",", header = TRUE)

# ==============================================================================
# 2. APERÇU DES DONNÉES
# ==============================================================================

# 6 premières lignes
head(sport)

# Structure : types, nombre d'individus et de variables
str(sport)

# Dimensions : 375 individus, 76 variables
dim(sport)

# ==============================================================================
# 3. RECODAGE DE LA VARIABLE deptgeo EN region
# ==============================================================================

# deptgeo contient trop de modalités (départements) avec des effectifs faibles.
# On regroupe en 2 modalités : Poitou-Charentes (16, 17, 79, 86) vs Autre.
# Si deptgeo vaut "Autre", on regarde deptgeo_Autre pour le vrai département.
sport$region <- ifelse(
  sport$deptgeo %in% c("16", "17", "79", "86") |
  (!is.na(sport$deptgeo_Autre) & sport$deptgeo_Autre %in% c("16", "17", "79", "86")),
  "Poitou-Charentes", "Autre"
)

table(sport$region)

# ==============================================================================
# 4. TABLEAUX CROISÉS : SPORT vs VARIABLES QUALITATIVES
# ==============================================================================

# 14 variables qualitatives renseignées pour tous les individus
TCD_sexe <- table(sport$sport, sport$sexe)
TCD_deptformation <- table(sport$sport, sport$deptformation)
TCD_niveau <- table(sport$sport, sport$niveau)
TCD_reprise <- table(sport$sport, sport$reprise)
TCD_alternant <- table(sport$sport, sport$alternant)
TCD_bourse <- table(sport$sport, sport$bourse)
TCD_travail <- table(sport$sport, sport$travail)
TCD_fumer <- table(sport$sport, sport$fumer)
TCD_alimentation <- table(sport$sport, sport$alimentation)
TCD_sante <- table(sport$sport, sport$sante)
TCD_fan <- table(sport$sport, sport$fan)
TCD_reussite <- table(sport$sport, sport$reussite)
TCD_region <- table(sport$sport, sport$region)

# Affichage
TCD_sexe
TCD_deptformation
TCD_niveau
TCD_reprise
TCD_alternant
TCD_bourse
TCD_travail
TCD_fumer
TCD_alimentation
TCD_sante
TCD_fan
TCD_reussite
TCD_region

# ==============================================================================
# 5. TESTS DU KHI-DEUX D'INDÉPENDANCE
# ==============================================================================

# H0 : sport et la variable sont indépendantes
# H1 : relation significative | Seuil : alpha = 0.05

khideux_sexe <- chisq.test(TCD_sexe)
khideux_deptformation <- chisq.test(TCD_deptformation)
khideux_niveau <- chisq.test(TCD_niveau)
khideux_reprise <- chisq.test(TCD_reprise)
khideux_alternant <- chisq.test(TCD_alternant)
khideux_bourse <- chisq.test(TCD_bourse)
khideux_travail <- chisq.test(TCD_travail)
khideux_fumer <- chisq.test(TCD_fumer)
khideux_alimentation <- chisq.test(TCD_alimentation)
khideux_sante <- chisq.test(TCD_sante)
khideux_fan <- chisq.test(TCD_fan)
khideux_reussite <- chisq.test(TCD_reussite)
khideux_region <- chisq.test(TCD_region)

# Affichage des effectifs théoriques pour vérifier la condition de validité
# du test du khi-deux : tous les effectifs théoriques doivent être >= 5.
# C'est ce qui a conduit à exclure la variable logement (effectifs < 5
# pour la modalité "Autre").
khideux_sexe$expected
khideux_deptformation$expected
khideux_niveau$expected
khideux_reprise$expected
khideux_alternant$expected
khideux_bourse$expected
khideux_travail$expected
khideux_fumer$expected
khideux_alimentation$expected
khideux_sante$expected
khideux_fan$expected
khideux_reussite$expected
khideux_region$expected

# ==============================================================================
# 6. TABLEAU RÉCAPITULATIF DES P-VALEURS
# ==============================================================================

noms_variables <- c("sexe", "deptformation", "niveau", "reprise", "alternant", 
                     "bourse", "travail", "fumer", "alimentation", 
                     "sante", "fan", "reussite", "region")

p_valeurs <- c(
  khideux_sexe$p.value, khideux_deptformation$p.value,
  khideux_niveau$p.value, khideux_reprise$p.value,
  khideux_alternant$p.value, khideux_bourse$p.value,
  khideux_travail$p.value,khideux_fumer$p.value, 
  khideux_alimentation$p.value,
  khideux_sante$p.value, khideux_fan$p.value,
  khideux_reussite$p.value, khideux_region$p.value
)

stats_khi2 <- c(
  khideux_sexe$statistic, khideux_deptformation$statistic,
  khideux_niveau$statistic, khideux_reprise$statistic,
  khideux_alternant$statistic, khideux_bourse$statistic,
  khideux_travail$statistic, 
  khideux_fumer$statistic, khideux_alimentation$statistic,
  khideux_sante$statistic, khideux_fan$statistic,
  khideux_reussite$statistic, khideux_region$statistic
)

significatif <- ifelse(p_valeurs < 0.05, "OUI ***", "Non")

tableau_pvaleurs <- data.frame(
  Variable = noms_variables,
  Khi2 = round(stats_khi2, 4),
  P_valeur = round(p_valeurs, 6),
  Significatif = significatif
)

print(tableau_pvaleurs)

# ==============================================================================
# 7. V DE CRAMER POUR LES TESTS SIGNIFICATIFS
# ==============================================================================

# V = sqrt(Khi2 / (n * m)) avec m = min(p-1, q-1)
# Fonction personnalisée : prend en entrée un tableau croisé (TCD)
# et le résultat du test chisq.test(), retourne le V de Cramer
V_cramer <- function(TCD, resultat_khi2) {
  n <- sum(TCD)
  p <- nrow(TCD)
  q <- ncol(TCD)
  m <- min(p - 1, q - 1)
  V <- sqrt(resultat_khi2$statistic / (n * m))
  return(as.numeric(V))
}

V_valeurs <- c(
  V_cramer(TCD_sexe, khideux_sexe),
  V_cramer(TCD_deptformation, khideux_deptformation),
  V_cramer(TCD_niveau, khideux_niveau),
  V_cramer(TCD_reprise, khideux_reprise),
  V_cramer(TCD_alternant, khideux_alternant),
  V_cramer(TCD_bourse, khideux_bourse),
  V_cramer(TCD_travail, khideux_travail),
  V_cramer(TCD_fumer, khideux_fumer),
  V_cramer(TCD_alimentation, khideux_alimentation),
  V_cramer(TCD_sante, khideux_sante),
  V_cramer(TCD_fan, khideux_fan),
  V_cramer(TCD_reussite, khideux_reussite),
  V_cramer(TCD_region, khideux_region)
)

V_affiche <- ifelse(p_valeurs < 0.05, round(V_valeurs, 4), NA)


# ==============================================================================
# 8. CONTRIBUTIONS AU KHI-DEUX
# ==============================================================================

# Contribution de chaque cellule au khi-deux total
khideux_sexe$residuals^2
khideux_deptformation$residuals^2
khideux_niveau$residuals^2
khideux_reprise$residuals^2
khideux_alternant$residuals^2
khideux_bourse$residuals^2
khideux_travail$residuals^2
khideux_fumer$residuals^2
khideux_alimentation$residuals^2
khideux_sante$residuals^2
khideux_fan$residuals^2
khideux_reussite$residuals^2
khideux_region$residuals^2

# ==============================================================================
# 9. TABLEAU FINAL RÉCAPITULATIF
# ==============================================================================

tableau_final <- data.frame(
  Variable = noms_variables,
  Khi2 = round(stats_khi2, 4),
  P_valeur = round(p_valeurs, 6),
  Significatif = significatif,
  V_Cramer = V_affiche
)

print(tableau_final)

# Liaison la plus forte
idx_max <- which.max(V_affiche)
cat("\n========================================\n")
cat("LIAISON LA PLUS FORTE :\n")
cat("Variable :", noms_variables[idx_max], "\n")
cat("V de Cramer :", round(V_valeurs[idx_max], 4), "\n")
cat("p-valeur :", round(p_valeurs[idx_max], 6), "\n")
cat("========================================\n")